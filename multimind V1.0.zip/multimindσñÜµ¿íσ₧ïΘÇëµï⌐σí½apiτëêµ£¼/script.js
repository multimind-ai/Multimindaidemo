document.addEventListener('DOMContentLoaded', function() {
    const userInput = document.getElementById('userInput');
    const submitBtn = document.getElementById('submitBtn');
    const kimiAnswer = document.getElementById('kimiAnswer');
    const deepseekAnswer = document.getElementById('deepseekAnswer');
    const chatgptAnswer = document.getElementById('chatgptAnswer');
    const clearBtn = document.getElementById('clearBtn');
    const copyInputBtn = document.getElementById('copyInputBtn');
    const answerTexts = document.querySelectorAll('.answer-text');
    const sidebar = document.querySelector('.sidebar');
    const container = document.querySelector('.container');
    const toggleBtn = document.querySelector('.sidebar-item.toggle');

    // 初始化模型切换功能
    initializeModelSwitching();

    // 侧边栏功能初始化
    initializeSidebar();

    // 初始化模型选择弹窗功能
    initializeModelSelectModal();

    // 添加同步更新函数
    function syncModelSelections() {
        // 获取所有可见回答框中选中的模型
        const selectedModels = new Set();
        document.querySelectorAll('.answer-box:not(.hidden)').forEach(box => {
            const selectedOption = box.querySelector('.model-option.selected');
            if (selectedOption) {
                selectedModels.add(selectedOption.getAttribute('data-model'));
            }
        });
        
        // 更新弹窗中所有复选框的状态
        document.querySelectorAll('#modelSelectModal input[type="checkbox"]').forEach(checkbox => {
            checkbox.checked = selectedModels.has(checkbox.value);
        });
    }

    // 模型切换功能初始化
    function initializeModelSwitching() {
        // 模型切换按钮点击事件
        document.querySelectorAll('.model-switch').forEach(button => {
            button.addEventListener('click', function(e) {
                e.stopPropagation();
                const modelOptions = this.querySelector('.model-options');
                
                // 关闭其他打开的选项菜单
                document.querySelectorAll('.model-options').forEach(menu => {
                    if (menu !== modelOptions) {
                        menu.classList.add('hidden');
                    }
                });
                
                // 切换当前菜单的显示/隐藏
                modelOptions.classList.toggle('hidden');
            });
        });

        // 点击页面其他地方关闭所有菜单
        document.addEventListener('click', function(e) {
            if (!e.target.closest('.model-switch')) {
                document.querySelectorAll('.model-options').forEach(menu => {
                    menu.classList.add('hidden');
                });
            }
        });

        // 模型选项点击事件
        document.querySelectorAll('.model-option').forEach(option => {
            option.addEventListener('click', async function(e) {
                e.stopPropagation();
                
                const modelName = this.getAttribute('data-model');
                const displayName = this.getAttribute('data-display');
                const currentAnswerBox = this.closest('.answer-box');
                
                // 更新当前答案框的标题和图标
                const title = currentAnswerBox.querySelector('.answer-title');
                const logo = title.querySelector('.answer-logo');
                const titleText = title.childNodes[2];
                
                logo.src = `images/${modelName}-logo.png`;
                logo.alt = `${modelName} Logo`;
                titleText.textContent = this.querySelector('.model-show-name').textContent;

                // 更新选中状态
                currentAnswerBox.querySelectorAll('.model-option').forEach(opt => {
                    opt.classList.remove('selected');
                });
                this.classList.add('selected');

                // 处理其他回答框中相同模型的情况
                const answerBoxes = document.querySelectorAll('.answer-box');
                const currentIndex = Array.from(answerBoxes).indexOf(currentAnswerBox);
                
                answerBoxes.forEach((box, index) => {
                    if (index !== currentIndex) {
                        const otherModelId = box.querySelector('.model-option.selected').getAttribute('data-model');
                        if (otherModelId === modelName) {
                            box.classList.add('hidden');
                        }
                    }
                });
                
                currentAnswerBox.classList.remove('hidden');
                
                // 同步更新模型选择状态
                syncModelSelections();
                
                // 更新回答区域的布局
                updateAnswersLayout();

                // 如果有输入的问题，调用新模型的 API
                const question = userInput.value.trim();
                if (question) {
                    const answerContent = currentAnswerBox.querySelector('.answer-content');
                    // 显示加载动画
                    answerContent.querySelector('.loading-container').classList.remove('hidden');
                    answerContent.querySelector('.answer-text').textContent = '';

                    try {
                        // 使用重试机制调用 API
                        if (modelName === 'kimi') {
                            await retryApiCall(() => callKimiApi(question, answerContent));
                        } else if (modelName === 'deepseek') {
                            await retryApiCall(() => simulateApiCall(answerContent, question));
                        } else if (modelName === 'deepseek-v3') {
                            await retryApiCall(() => callDeepSeekV3Api(question, answerContent));
                        } else if (modelName === 'deepseek-reasoner') {
                            await retryApiCall(() => callDeepSeekReasonerApi(question, answerContent));
                        } else if (modelName === 'chatgpt') {
                            await retryApiCall(() => callChatGPTApi(question, answerContent));
                        }
                    } catch (error) {
                        console.error('Error:', error);
                        answerContent.querySelector('.loading-container').classList.add('hidden');
                        answerContent.querySelector('.answer-text').textContent = 
                            error.message.includes('429') 
                                ? "当前请求较多，请稍后再试"
                                : "切换模型后调用失败：" + error.message;
                    }
                }

                // 隐藏选项菜单
                this.closest('.model-options').classList.add('hidden');
            });
        });
    }

    // 侧边栏功能初始化
    function initializeSidebar() {
        const toggleBtn = document.querySelector('.sidebar-item.toggle');
        const sidebar = document.querySelector('.sidebar');

        toggleBtn?.addEventListener('click', function() {
            sidebar.classList.toggle('collapsed');
        });

        // 响应式处理
        function handleResize() {
            // 仅在移动端自动收起侧边栏
            if (window.innerWidth <= 768) {
                sidebar.classList.add('collapsed');
            } else {
                sidebar.classList.remove('collapsed');
            }
        }

        window.addEventListener('resize', handleResize);
        handleResize(); // 初始化时执行一次
    }

    submitBtn.addEventListener('click', async function() {
        const question = userInput.value.trim();
        if (!question) {
            showToast('请先输入问题');
            return;
        }

        // 获取所有未隐藏的回答框
        const visibleAnswerBoxes = document.querySelectorAll('.answer-box:not(.hidden)');
        
        if (visibleAnswerBoxes.length === 0) {
            showToast('请至少选择一个模型');
            return;
        }
        
        // 验证所有选中模型的API
        let hasInvalidApi = false;
        visibleAnswerBoxes.forEach(box => {
            const selectedOption = box.querySelector('.model-option.selected');
            if (!selectedOption) {
                hasInvalidApi = true;
                return;
            }
            const selectedModel = selectedOption.getAttribute('data-model');
            if (!validateApiKey(selectedModel)) {
                hasInvalidApi = true;
            }
        });
        
        if (hasInvalidApi) {
            showToast('请先填写所有选中模型的API Key');
            return;
        }
        
        // 创建请求数组，按顺序同时发送
        const requests = Array.from(visibleAnswerBoxes).map(box => {
            const answerContent = box.querySelector('.answer-content');
            const selectedOption = box.querySelector('.model-option.selected');
            if (!selectedOption) {
                console.error('No selected model found for answer box');
                return Promise.resolve();
            }
            const selectedModel = selectedOption.getAttribute('data-model');
            
            // 显示加载动画
            answerContent.querySelector('.loading-container').classList.remove('hidden');
            answerContent.querySelector('.answer-text').textContent = '';

            // 返回对应的 API 调用 Promise
            return (async () => {
                try {
                    if (selectedModel === 'kimi') {
                        await retryApiCall(() => callKimiApi(question, answerContent));
                    } else if (selectedModel === 'deepseek') {
                        await retryApiCall(() => simulateApiCall(answerContent, question));
                    } else if (selectedModel === 'deepseek-v3') {
                        await retryApiCall(() => callDeepSeekV3Api(question, answerContent));
                    } else if (selectedModel === 'deepseek-reasoner') {
                        await retryApiCall(() => callDeepSeekReasonerApi(question, answerContent));
                    } else if (selectedModel === 'chatgpt') {
                        await retryApiCall(() => callChatGPTApi(question, answerContent));
                    }
                } catch (error) {
                    console.error('Error:', error);
                    answerContent.querySelector('.loading-container').classList.add('hidden');
                    answerContent.querySelector('.answer-text').textContent = 
                        error.message.includes('429') 
                            ? "当前请求较多，请稍后再试"
                            : "调用失败：" + error.message;
                }
            })();
        });

        // 同时发送所有请求
        await Promise.all(requests).then(() => {
            // 延迟一小段时间确保所有回答都已更新
            setTimeout(updateNotepad, 100);
        });
    });

    // 修改刷新按钮和复制按钮的事件处理
    document.querySelectorAll('.answer-title .icon-btn:not(.model-switch)').forEach(button => {
        const isRefreshButton = button.querySelector('img[alt="refresh"]');
        const isCopyButton = button.querySelector('img[alt="copy"]');
        
        if (isRefreshButton) {
            // 刷新按钮事件
            button.addEventListener('click', async function() {
                const question = userInput.value.trim();
                if (!question) {
                    showToast('请先输入问题');
                    return;
                }

                const answerBox = this.closest('.answer-box');
                const answerContent = answerBox.querySelector('.answer-content');
                const selectedModel = answerBox.querySelector('.model-option.selected').getAttribute('data-model');

                // 显示加载动画
                answerContent.querySelector('.loading-container').classList.remove('hidden');
                answerContent.querySelector('.answer-text').textContent = '';

                try {
                    if (selectedModel === 'kimi') {
                        await retryApiCall(() => callKimiApi(question, answerContent));
                    } else if (selectedModel === 'deepseek') {
                        await retryApiCall(() => simulateApiCall(answerContent, question));
                    } else if (selectedModel === 'deepseek-v3') {
                        await retryApiCall(() => callDeepSeekV3Api(question, answerContent));
                    } else if (selectedModel === 'deepseek-reasoner') {
                        await retryApiCall(() => callDeepSeekReasonerApi(question, answerContent));
                    } else if (selectedModel === 'chatgpt') {
                        await retryApiCall(() => callChatGPTApi(question, answerContent));
                    }
                } catch (error) {
                    console.error('Error:', error);
                    answerContent.querySelector('.loading-container').classList.add('hidden');
                    answerContent.querySelector('.answer-text').textContent = 
                        error.message.includes('429') 
                            ? "当前请求较多，请稍后再试"
                            : "刷新失败：" + error.message;
                }
            });
        } else if (isCopyButton) {
            // 复制按钮事件
            button.addEventListener('click', function() {
                const answerBox = this.closest('.answer-box');
                const answerText = answerBox.querySelector('.answer-text');
                
                // 检查是否正在加载
                const isLoading = !answerBox.querySelector('.loading-container').classList.contains('hidden');
                if (isLoading) {
                    showToast('内容加载中，请稍后复制');
                    return;
                }
                
                // 检查是否有内容可复制
                if (!answerText || !answerText.textContent || answerText.textContent.trim() === '') {
                    showToast('暂无内容可复制');
                    return;
                }
                
                // 复制内容
                navigator.clipboard.writeText(answerText.textContent)
                    .then(() => {
                        showToast('复制成功', 'success');
                    })
                    .catch(err => {
                        console.error('复制失败:', err);
                        showToast('复制失败，请重试');
                    });
            });
        }
    });

    // 封装 Toast 功能
    function showToast(message, type = 'error') {
        const container = document.querySelector('.toast-container');
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.textContent = message;
        
        // 添加到容器
        container.appendChild(toast);
        
        // 设置动画结束监听器
        toast.addEventListener('animationend', (e) => {
            if (e.animationName === 'fadeOut') {
                container.removeChild(toast);
            }
        });

        // 自动移除旧的 toast
        const toasts = container.querySelectorAll('.toast');
        if (toasts.length > 3) { // 限制最大显示数量
            container.removeChild(toasts[0]);
        }
    }

    // 清除功能
    clearBtn.addEventListener('click', function() {
        // 清除输入框
        userInput.value = '';
        // 清除所有回答
        answerTexts.forEach(text => {
            text.textContent = '';
        });
    });

    // 生成用户名
    function generateUsername() {
        const timestamp = Date.now().toString();
        const lastFourDigits = timestamp.slice(-4);
        
        // 从 localStorage 获取当前时间戳下的用户数量
        const currentTime = Math.floor(Date.now() / 1000); // 取秒级时间戳
        const userCountKey = `userCount_${currentTime}`;
        let userCount = parseInt(localStorage.getItem(userCountKey) || '0');
        
        // 增加用户数量并存储
        userCount++;
        localStorage.setItem(userCountKey, userCount.toString());
        
        // 5分钟后清理旧的计数器
        setTimeout(() => {
            const oldKeys = Object.keys(localStorage).filter(key => 
                key.startsWith('userCount_') && 
                parseInt(key.split('_')[1]) < currentTime - 300
            );
            oldKeys.forEach(key => localStorage.removeItem(key));
        }, 1000);
    }

    // 生成用户名
    generateUsername();

    // 添加滚动功能
    const backToTop = document.getElementById('backToTop');
    const backToBottom = document.getElementById('backToBottom');

    // 返回顶部
    backToTop.addEventListener('click', function() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });

    // 返回底部
    backToBottom.addEventListener('click', function() {
        window.scrollTo({
            top: document.documentElement.scrollHeight,
            behavior: 'smooth'
        });
    });

    // 记事本功能
    const sidebarNotepadBtn = document.getElementById('notepadBtn');
    const floatNotepadBtn = document.querySelector('.float-toolbar .toolbar-btn');
    const notepadWindow = document.getElementById('notepadWindow');
    const minimizeNotepad = document.getElementById('minimizeNotepad');
    const closeNotepad = document.getElementById('closeNotepad');
    const saveNotepad = document.getElementById('saveNotepad');
    const notepadContent = document.querySelector('.notepad-content');
    const notepadHeader = document.querySelector('.notepad-header');
    const notificationDot = document.querySelector('.notification-dot');
    const importNotepad = document.getElementById('importNotepad');

    // 打开记事本
    function openNotepad() {
        // 显示记事本
        notepadWindow.classList.remove('hidden');
        // 设置记事本位置为屏幕中心
        const windowWidth = window.innerWidth;
        const windowHeight = window.innerHeight;
        const notepadWidth = 600; // 记事本默认宽度
        const notepadHeight = 400; // 记事本默认高度
        
        const left = (windowWidth - notepadWidth) / 2;
        const top = (windowHeight - notepadHeight) / 2;
        
        notepadWindow.style.left = `${left}px`;
        notepadWindow.style.top = `${top}px`;
        notepadWindow.style.transform = 'none';
        
        // 移除小红点提示
        const notificationDots = document.querySelectorAll('.notification-dot');
        notificationDots.forEach(dot => dot.classList.add('hidden'));

        // 同步当前问题和回答内容
        updateNotepadContent();
    }

    // 记事本按钮点击事件（侧边栏和飘窗工具栏）
    if (sidebarNotepadBtn) {
        sidebarNotepadBtn.addEventListener('click', openNotepad);
    }
    if (floatNotepadBtn) {
        floatNotepadBtn.addEventListener('click', openNotepad);
    }

    // 更新记事本内容
    function updateNotepadContent() {
        const question = userInput.value.trim();
        if (!question) return;

        const visibleAnswerBoxes = document.querySelectorAll('.answer-box:not(.hidden)');
        const answers = [];

        visibleAnswerBoxes.forEach(box => {
            const answerText = box.querySelector('.answer-text').textContent;
            const selectedOption = box.querySelector('.model-option.selected');
            if (!selectedOption || !answerText.trim()) return;

            const modelName = selectedOption.querySelector('.model-show-name').textContent;
            answers.push({
                model: modelName,
                text: answerText.trim()
            });
        });

        if (answers.length === 0) return;

        let content = `问题：\n${question}\n\n`;
        answers.forEach(answer => {
            content += `【${answer.model}回答】\n${answer.text}\n\n`;
        });

        notepadContent.innerHTML = content.replace(/\n/g, '<br>');
        notepadContent.scrollTop = 0;
    }

    // 最小化记事本
    minimizeNotepad.addEventListener('click', function() {
        notepadWindow.classList.add('hidden');  // 隐藏弹窗
        notificationDot.classList.remove('hidden');  // 显示小红点
    });

    // 关闭记事本
    closeNotepad.addEventListener('click', function() {
        notepadWindow.classList.add('hidden');  // 隐藏弹窗
        notepadContent.innerHTML = '';  // 清空内容
        notificationDot.classList.add('hidden');  // 隐藏小红点
    });

    // 更新记事本内容的函数
    function updateNotepad() {
        // 如果记事本已经打开，则更新内容
        if (!notepadWindow.classList.contains('hidden')) {
            openNotepad();
        }
    }

    // 保存按钮点击事件
    const filenameModal = document.getElementById('filenameModal');
    const filenameInput = document.getElementById('filenameInput');
    const cancelSave = document.getElementById('cancelSave');
    const confirmSave = document.getElementById('confirmSave');

    saveNotepad.addEventListener('click', function() {
        const notepadContent = document.querySelector('.notepad-content');
        if (!notepadContent.textContent.trim()) {
            showToast('记事本内容为空');
            return;
        }

        // 显示文件名输入弹窗
        filenameInput.value = generateDefaultFilename();
        filenameModal.classList.remove('hidden');
    });

    // 取消保存
    cancelSave.addEventListener('click', function() {
        filenameModal.classList.add('hidden');
    });

    // 确认保存
    confirmSave.addEventListener('click', function() {
        const filename = filenameInput.value.trim();
        if (!filename) {
            showToast('请输入文件名');
            return;
        }

        const notepadContent = document.querySelector('.notepad-content').textContent;
        const blob = new Blob([notepadContent], { type: 'text/plain;charset=utf-8' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = `${filename}.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(a.href);

        // 隐藏弹窗并显示成功提示
        filenameModal.classList.add('hidden');
        showToast('保存成功', 'success');
    });

    // 按下回车键也可以保存
    filenameInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            confirmSave.click();
        }
    });

    // 生成默认文件名
    function generateDefaultFilename() {
        const question = userInput.value.trim();
        if (question) {
            // 使用问题的前10个字符
            return question.slice(0, 10).replace(/[\\/:*?"<>|]/g, '_');
        } else {
            // 使用当前时间
            const now = new Date();
            const dateStr = now.toLocaleDateString().replace(/\//g, '');
            const timeStr = now.toLocaleTimeString().replace(/:/g, '');
            return `记事本_${dateStr}_${timeStr}`;
        }
    }

    // 添加拖动和调整大小功能
    const resizeHandles = notepadWindow.querySelectorAll('.resize-handle');

    // 拖动功能
    let isDragging = false;
    let currentX;
    let currentY;
    let initialX;
    let initialY;

    notepadHeader.addEventListener('mousedown', initDrag);

    function initDrag(e) {
        if (e.target === notepadHeader || e.target.closest('.notepad-title')) {
            isDragging = true;
            initialX = e.clientX - notepadWindow.offsetLeft;
            initialY = e.clientY - notepadWindow.offsetTop;
        }
    }

    document.addEventListener('mousemove', drag);
    document.addEventListener('mouseup', stopDrag);

    function drag(e) {
        if (isDragging) {
            e.preventDefault();
            currentX = e.clientX - initialX;
            currentY = e.clientY - initialY;
            
            notepadWindow.style.left = `${currentX}px`;
            notepadWindow.style.top = `${currentY}px`;
            notepadWindow.style.transform = 'none';
        }
    }

    function stopDrag() {
        isDragging = false;
    }

    // 调整大小功能
    resizeHandles.forEach(handle => {
        handle.addEventListener('mousedown', initResize);
    });

    function initResize(e) {
        e.preventDefault();
        e.stopPropagation();

        const notepad = notepadWindow;
        const direction = e.target.className.split(' ')[1];
        const startX = e.clientX;
        const startY = e.clientY;
        const startWidth = notepad.offsetWidth;
        const startHeight = notepad.offsetHeight;
        const startLeft = notepad.offsetLeft;
        const startTop = notepad.offsetTop;

        function resize(e) {
            if (direction.includes('right')) {
                const width = startWidth + (e.clientX - startX);
                if (width >= 300) notepad.style.width = width + 'px';
            }
            if (direction.includes('bottom')) {
                const height = startHeight + (e.clientY - startY);
                if (height >= 200) notepad.style.height = height + 'px';
            }
            if (direction.includes('left')) {
                const width = startWidth - (e.clientX - startX);
                if (width >= 300) {
                    notepad.style.width = width + 'px';
                    notepad.style.left = startLeft + (e.clientX - startX) + 'px';
                }
            }
            if (direction.includes('top')) {
                const height = startHeight - (e.clientY - startY);
                if (height >= 200) {
                    notepad.style.height = height + 'px';
                    notepad.style.top = startTop + (e.clientY - startY) + 'px';
                }
            }
        }

        function stopResize() {
            window.removeEventListener('mousemove', resize);
            window.removeEventListener('mouseup', stopResize);
        }

        window.addEventListener('mousemove', resize);
        window.addEventListener('mouseup', stopResize);
    }

    // 添加导入功能
    importNotepad.addEventListener('click', function() {
        const question = userInput.value.trim();
        if (!question) {
            showToast('请先输入问题');
            return;
        }
        
        // 获取所有未隐藏的回答框
        const visibleAnswerBoxes = document.querySelectorAll('.answer-box:not(.hidden)');
        
        if (visibleAnswerBoxes.length === 0) {
            showToast('请至少选择一个模型');
            return;
        }
        
        const answers = [];
        
        // 收集所有有内容的回答
        Array.from(visibleAnswerBoxes).forEach(box => {
            const answerText = box.querySelector('.answer-text').textContent;
            const selectedModel = box.querySelector('.model-option.selected').getAttribute('data-display');
            
            // 只收集有内容的回答，并保持段落格式
            if (answerText && answerText.trim()) {
                answers.push({
                    model: selectedModel,
                    text: answerText.split('\n')
                        .map(line => line.trim())
                        .filter(line => line)  // 移除空行
                        .join('\n')
                });
            }
        });
        
        if (answers.length === 0) {
            showToast('暂无模型返回结果');
            return;
        }
        
        // 构建同步内容，使用 <br> 标签保持换行格式
        let syncContent = `问题：\n${question}\n\n`;
        
        // 添加所有有内容的回答，保持段落格式
        answers.forEach(answer => {
            syncContent += `【${answer.model}回答】\n`;  // 标题另起一行
            syncContent += `${answer.text}\n\n`;  // 内容保持原有格式
        });
        
        // 获取记事本内容元素
        const notepadContent = document.querySelector('.notepad-content');
        
        // 直接更新记事本内容，不保留之前的内容
        notepadContent.innerHTML = syncContent.replace(/\n/g, '<br>');
        
        // 滚动到顶部
        notepadContent.scrollTop = 0;
        
        showToast('同步成功', 'success');
    });

    // 修改模型选择弹窗功能初始化
    function initializeModelSelectModal() {
        const modal = document.getElementById('modelSelectModal');
        const modelSelectBtn = document.getElementById('modelSelectBtn');
        const closeBtn = modal.querySelector('.close-btn');
        const modelCheckboxes = modal.querySelectorAll('input[type="checkbox"]');
        const helpModal = document.getElementById('helpModal');
        const helpCloseBtn = helpModal.querySelector('.close-btn');
        const apiInputs = document.querySelectorAll('.model-api-input');
        const helpLinks = document.querySelectorAll('.help-link');

        // 从localStorage加载API keys
        function loadApiKeys() {
            apiInputs.forEach(input => {
                const modelId = input.getAttribute('data-model');
                const savedKey = localStorage.getItem(`${modelId}-api-key`);
                if (savedKey) {
                    // 处理API显示
                    const maskedKey = maskApiKey(savedKey);
                    input.value = maskedKey;
                    input.setAttribute('data-full-api', savedKey);
                    
                    // 显示查看按钮
                    const toggleBtn = input.nextElementSibling;
                    if (toggleBtn) {
                        toggleBtn.style.display = 'block';
                    }
                }
            });
        }

        // 清理已删除的API记录
        function cleanupDeletedApiKeys() {
            apiInputs.forEach(input => {
                const modelId = input.getAttribute('data-model');
                const currentValue = input.value.trim();
                const savedKey = localStorage.getItem(`${modelId}-api-key`);
                
                // 如果输入框为空但localStorage中还有记录，则删除该记录
                if (!currentValue && savedKey) {
                    localStorage.removeItem(`${modelId}-api-key`);
                    input.removeAttribute('data-full-api');
                    
                    // 隐藏查看按钮
                    const toggleBtn = input.nextElementSibling;
                    if (toggleBtn) {
                        toggleBtn.style.display = 'none';
                    }
                }
            });
        }

        // 初始化时加载API keys
        loadApiKeys();

        // API输入框事件处理
        apiInputs.forEach(input => {
            const toggleBtn = input.parentElement.querySelector('.api-toggle-visibility');
            
            // 初始化时隐藏查看按钮
            if (toggleBtn) {
                toggleBtn.style.display = input.value ? 'block' : 'none';
            }
            
            input.addEventListener('input', function() {
                const modelId = this.getAttribute('data-model');
                const apiKey = this.value;
                const checkbox = document.getElementById(modelId);
                
                // 如果正在输入，暂时显示完整内容
                this.setAttribute('data-full-api', apiKey);
                
                // 当输入框失去焦点时再保存并遮罩
                this.addEventListener('blur', function() {
                    if (apiKey.trim()) {
                        saveApiKey(modelId, apiKey);
                    } else {
                        // 如果输入框被清空，删除API记录
                        clearApiRecord(modelId);
                        // 如果模型被选中，取消选中
                        if (checkbox && checkbox.checked) {
                            checkbox.checked = false;
                        }
                    }
                    saveModelSelections();
                }, { once: true });
            });

            // 阻止点击输入框时触发模型选择
            input.addEventListener('click', function(e) {
                e.stopPropagation();
            });
            
            // 查看按钮点击事件
            if (toggleBtn) {
                toggleBtn.addEventListener('click', function() {
                    const input = this.parentElement.querySelector('.model-api-input');
                    const fullApi = input.getAttribute('data-full-api');
                    const img = this.querySelector('img');
                    
                    if (input.value === fullApi) {
                        // 当前显示完整API，切换到遮罩状态
                        input.value = maskApiKey(fullApi);
                        img.src = 'images/eye-outlined.png';
                        img.alt = 'show api';
                    } else {
                        // 当前显示遮罩API，切换到完整状态
                        input.value = fullApi;
                        img.src = 'images/eye-close-outlined.png';
                        img.alt = 'hide api';
                    }
                });
            }
        });

        // 帮助链接点击事件
        helpLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const modelId = this.getAttribute('data-model');
                modal.classList.add('hidden');
                
                // 显示帮助弹窗
                helpModal.classList.remove('hidden');
                
                // 隐藏所有帮助内容
                document.querySelectorAll('.help-section').forEach(section => {
                    section.style.display = 'none';
                });
                
                // 显示对应模型的帮助内容
                const helpSection = document.getElementById(`${modelId}-help`);
                if (helpSection) {
                    helpSection.style.display = 'block';
                }
            });
        });

        // 关闭帮助弹窗
        helpCloseBtn.addEventListener('click', () => {
            helpModal.classList.add('hidden');
        });

        // 点击帮助弹窗外部关闭
        helpModal.addEventListener('click', (e) => {
            if (e.target === helpModal) {
                helpModal.classList.add('hidden');
            }
        });

        // 打开弹窗
        modelSelectBtn.addEventListener('click', () => {
            modal.classList.remove('hidden');
            syncModelSelections();
        });

        // 关闭弹窗时清理已删除的API记录
        closeBtn.addEventListener('click', () => {
            cleanupDeletedApiKeys();
            modal.classList.add('hidden');
        });

        // 点击弹窗外部关闭时也清理API记录
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                cleanupDeletedApiKeys();
                modal.classList.add('hidden');
            }
        });

        // 复选框变化事件
        modelCheckboxes.forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                const modelId = this.id;
                const apiInput = document.querySelector(`.model-api-input[data-model="${modelId}"]`);
                
                // 清除所有API错误提示
                clearAllApiErrors();
                
                if (this.checked) {
                    // 验证API key
                    if (!apiInput || !apiInput.value) {
                        this.checked = false;
                        showToast('请先填写API Key');
                        apiInput.classList.add('error');
                        apiInput.placeholder = '请先填写API Key';
                        return;
                    }
                }
                
                // 更新回答框显示状态
                const targetBox = document.querySelector(`.answer-box[data-model="${modelId}"]`);
                    if (targetBox) {
                    targetBox.classList.toggle('hidden', !this.checked);
                }
                
                updateAnswersLayout();
                saveModelSelections();
            });
        });
    }
    
    // 更新回答区域的布局
    function updateAnswersLayout() {
        const visibleAnswerBoxes = document.querySelectorAll('.answer-box:not(.hidden)');
        const totalBoxes = visibleAnswerBoxes.length;
        const answersSection = document.querySelector('.answers-section');
        const containerWidth = document.querySelector('.container').offsetWidth;
        
        // 重置所有回答框的样式
        visibleAnswerBoxes.forEach(box => {
            box.style.width = '';
            box.style.fontSize = '';
            box.style.marginBottom = '';
        });
        
        // 重置 answers-section 的样式
        answersSection.style.display = '';
        answersSection.style.gridTemplateColumns = '';
        answersSection.style.gap = '';
        
        // 如果容器宽度小于768px，强制使用单列布局
        if (containerWidth < 768) {
            answersSection.style.display = 'flex';
            answersSection.style.flexDirection = 'column';
            answersSection.style.gap = '20px';
            
            visibleAnswerBoxes.forEach(box => {
                box.style.width = '100%';
                box.style.fontSize = '14px';
                box.style.marginBottom = '0';
            });
            return;
        }
        
        // 根据显示的回答框数量调整布局
        if (totalBoxes === 1) {
            // 1个框时，占据整个宽度
            answersSection.style.display = 'block';
            answersSection.style.gap = '0';
            
            visibleAnswerBoxes[0].style.width = '100%';
            visibleAnswerBoxes[0].style.fontSize = '14px';
            visibleAnswerBoxes[0].style.marginBottom = '20px';
        } else if (totalBoxes === 2) {
            // 2个框时，平分宽度
            answersSection.style.display = 'grid';
            answersSection.style.gridTemplateColumns = 'repeat(2, 1fr)';
            answersSection.style.gap = '20px';
            
            visibleAnswerBoxes.forEach(box => {
                box.style.width = '100%';
                box.style.fontSize = '14px';
                box.style.marginBottom = '0';
            });
        } else if (totalBoxes === 3) {
            // 3个框时，3列布局
            answersSection.style.display = 'grid';
            answersSection.style.gridTemplateColumns = 'repeat(3, 1fr)';
            answersSection.style.gap = '20px';
            
            visibleAnswerBoxes.forEach(box => {
                box.style.width = '100%';
                box.style.fontSize = '14px';
                box.style.marginBottom = '0';
            });
        } else if (totalBoxes === 4) {
            // 4个框时，2x2网格布局
            answersSection.style.display = 'grid';
            answersSection.style.gridTemplateColumns = 'repeat(2, 1fr)';
            answersSection.style.gap = '20px';
            
            visibleAnswerBoxes.forEach(box => {
                box.style.width = '100%';
                box.style.fontSize = '13px';
                box.style.marginBottom = '0';
            });
        } else {
            // 5-6个框时，3x2网格布局
            answersSection.style.display = 'grid';
            answersSection.style.gridTemplateColumns = 'repeat(3, 1fr)';
            answersSection.style.gap = '20px';
            
            visibleAnswerBoxes.forEach(box => {
                box.style.width = '100%';
                box.style.fontSize = '13px';
                box.style.marginBottom = '0';
            });
        }
    }

    // 添加窗口大小变化监听器
    window.addEventListener('resize', function() {
        updateAnswersLayout();
    });

    // 帮助页面返回按钮点击事件
    document.querySelector('#helpModal .back-btn').addEventListener('click', function() {
        document.getElementById('helpModal').classList.add('hidden');
        document.getElementById('modelSelectModal').classList.remove('hidden');
    });

    // 初始化API文件处理
    initializeApiFileHandling();

    // 保存模型选择状态
    function saveModelSelections() {
        const modelCheckboxes = document.querySelectorAll('.model-item input[type="checkbox"]');
        const selections = {};
        
        modelCheckboxes.forEach(checkbox => {
            const modelId = checkbox.id;
            const apiInput = document.querySelector(`.model-api-input[data-model="${modelId}"]`);
            // 只有当API已填写且模型被选中时才保存状态
            if (apiInput && apiInput.value && checkbox.checked) {
                selections[modelId] = true;
            }
        });
        
        localStorage.setItem('modelSelections', JSON.stringify(selections));
    }

    // 恢复模型选择状态
    function restoreModelSelections() {
        const savedSelections = localStorage.getItem('modelSelections');
        const modelCheckboxes = document.querySelectorAll('.model-item input[type="checkbox"]');
        
        // 首先确保所有复选框都是未选中状态
        modelCheckboxes.forEach(checkbox => {
            checkbox.checked = false;
        });
        
        // 确保所有回答框都是隐藏状态
        document.querySelectorAll('.answer-box').forEach(box => {
            box.classList.add('hidden');
        });
        
        // 如果没有保存的选择状态，直接返回
        if (!savedSelections) return;
        
        const selections = JSON.parse(savedSelections);
        
        // 恢复选中状态和显示对应的回答框
        modelCheckboxes.forEach(checkbox => {
            const modelId = checkbox.id;
            const apiInput = document.querySelector(`.model-api-input[data-model="${modelId}"]`);
            // 只有当API存在且之前被选中时才恢复选中状态
            if (apiInput && apiInput.value && selections[modelId]) {
                checkbox.checked = true;
                // 显示对应的回答框
                const targetBox = document.querySelector(`.answer-box[data-model="${modelId}"]`);
                if (targetBox) {
                    targetBox.classList.remove('hidden');
                }
            }
        });
        
        // 更新回答区域的布局
        updateAnswersLayout();
    }

    // 在页面加载时恢复模型选择状态
    restoreModelSelections();

    // 在API输入变化时更新模型选择状态
    function initializeApiInputs() {
        // ... existing code ...
        apiInputs.forEach(input => {
            input.addEventListener('input', () => {
                const modelId = input.dataset.model;
                const checkbox = document.getElementById(modelId);
                
                if (!input.value && checkbox.checked) {
                    checkbox.checked = false;
                }
                saveModelSelections();
            });
        });
        // ... existing code ...
    }
});

// 获取API key的函数
function getApiKey(modelId) {
    const input = document.querySelector(`.model-api-input[data-model="${modelId}"]`);
    if (!input) return null;
    
    // 如果输入框显示的是遮罩后的API，则获取完整API
    const fullApi = input.getAttribute('data-full-api');
    return fullApi || input.value.trim();
}

// 验证API key是否已填写
function validateApiKey(modelId) {
    const apiKey = getApiKey(modelId);
    const input = document.querySelector(`.model-api-input[data-model="${modelId}"]`);
    
    // 如果input存在且有data-full-api属性，说明API已保存
    if (input && input.getAttribute('data-full-api')) {
        input.classList.remove('error');
        input.setAttribute('placeholder', '请输入API Key');
        return true;
    }
    
    if (!apiKey) {
        if (input) {
            input.classList.add('error');
            input.setAttribute('placeholder', '请先填写API Key');
        }
        return false;
    }
    
    // 移除错误状态和提示
    if (input) {
        input.classList.remove('error');
        input.setAttribute('placeholder', '请输入API Key');
    }
    return true;
}

// 清除所有API错误提示
function clearAllApiErrors() {
    document.querySelectorAll('.model-api-input').forEach(input => {
        input.classList.remove('error');
        input.setAttribute('placeholder', '请输入API Key');
    });
}

// 遮罩API key
function maskApiKey(apiKey) {
    if (apiKey.length <= 4) return apiKey;
    return apiKey.slice(0, 2) + '*'.repeat(apiKey.length - 4) + apiKey.slice(-2);
}

// 保存API key到localStorage
function saveApiKey(modelId, apiKey) {
    if (apiKey.trim()) {
        // 保存到localStorage
        localStorage.setItem(`${modelId}-api-key`, apiKey);
        
        // 移除错误状态
        const input = document.querySelector(`.model-api-input[data-model="${modelId}"]`);
        input.classList.remove('error');
        input.setAttribute('placeholder', '请输入API Key');
        
        // 保存完整API到data属性
        input.setAttribute('data-full-api', apiKey);
        
        // 显示遮罩后的API
        input.value = maskApiKey(apiKey);
        
        // 显示查看按钮
        const toggleBtn = input.parentElement.querySelector('.api-toggle-visibility');
        if (toggleBtn) {
            toggleBtn.style.display = 'block';
        }
    }
}

// 清除API记录
function clearApiRecord(modelId) {
    // 从localStorage中删除
    localStorage.removeItem(`${modelId}-api-key`);
    
    // 清空输入框
    const input = document.querySelector(`.model-api-input[data-model="${modelId}"]`);
    if (input) {
        input.value = '';
        input.removeAttribute('data-full-api');
        input.classList.remove('error');
        
        // 隐藏查看按钮
        const toggleBtn = input.parentElement.querySelector('.api-toggle-visibility');
        if (toggleBtn) {
            toggleBtn.style.display = 'none';
        }

        // 检查对应的复选框是否被选中
        const checkbox = document.querySelector(`input[type="checkbox"][value="${modelId}"]`);
        if (checkbox && checkbox.checked) {
            // 如果模型仍被选中，显示API输入提示
            input.classList.add('error');
            input.setAttribute('placeholder', '请先填写API Key');
        } else {
            // 如果模型未被选中，显示默认提示
            input.setAttribute('placeholder', '请输入API Key');
        }
    }
}

// 监听文件拖放事件
function initializeApiFileHandling() {
    const apiInputs = document.querySelectorAll('.model-api-input');
    
    apiInputs.forEach(input => {
        const modelId = input.getAttribute('data-model');
        
        input.addEventListener('dragover', (e) => {
            e.preventDefault();
            e.stopPropagation();
            input.classList.add('dragover');
        });
        
        input.addEventListener('dragleave', () => {
            input.classList.remove('dragover');
        });
        
        input.addEventListener('drop', (e) => {
            e.preventDefault();
            e.stopPropagation();
            input.classList.remove('dragover');
            showToast('不支持拖放导入API Key');
        });
    });
}

// 调用 Kimi API 的函数
async function callKimiApi(question, targetEl) {
    try {
        const apiKey = getApiKey('kimi');
        if (!apiKey) {
            throw new Error('请先填写Kimi API Key');
        }

        console.log('准备发送请求到 Kimi...');
        const response = await fetch('https://api.moonshot.cn/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`
            },
            body: JSON.stringify({
                model: "moonshot-v1-8k",
                messages: [
                    {
                        role: "system",
                        content: "你是 Kimi，由 Moonshot AI 提供的人工智能助手，你更擅长中文和英文的对话。"
                    },
                    {
                        role: "user",
                        content: question
                    }
                ],
                temperature: 0.3
            })
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        console.log('收到 Kimi 响应:', data);
        
        targetEl.querySelector('.loading-container').classList.add('hidden');
        targetEl.querySelector('.answer-text').textContent = data.choices[0].message.content;
    } catch (error) {
        console.error('Error calling Kimi API:', error);
        targetEl.querySelector('.loading-container').classList.add('hidden');
        throw error;
    }
}

// 修改模拟调用为实际的 DeepSeek API 调用
async function simulateApiCall(targetEl, question) {
    try {
        console.log('准备发送请求到 DeepSeek...');
        const response = await fetch('https://api.siliconflow.cn/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer sk-psuadigewghpocbjfpprgltgvsaoqlunisgwutjnacofgsjo'
            },
            body: JSON.stringify({
                model: "deepseek-ai/DeepSeek-R1-Distill-Llama-8B",
                messages: [
                    {
                        role: "system",
                        content: "你是 DeepSeek 开发的 AI 助手"
                    },
                    {
                        role: "user",
                        content: question
                    }
                ],
                temperature: 0.6
            })
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        console.log('收到 DeepSeek 响应:', data);
        
        targetEl.querySelector('.loading-container').classList.add('hidden');
        targetEl.querySelector('.answer-text').textContent = data.choices[0].message.content;
    } catch (error) {
        console.error('Error calling DeepSeek API:', error);
        targetEl.querySelector('.loading-container').classList.add('hidden');
        throw error;
    }
}

// 添加 DeepSeek-V3 API 调用函数
async function callDeepSeekV3Api(question, targetEl) {
    try {
        const apiKey = getApiKey('deepseek-v3');
        if (!apiKey) {
            throw new Error('请先填写DeepSeek-V3 API Key');
        }

        console.log('准备发送请求到 DeepSeek-V3...');
        const response = await fetch('https://api.deepseek.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`
            },
            body: JSON.stringify({
                model: "deepseek-chat",
                messages: [
                    {
                        role: "system",
                        content: "你是 DeepSeek-V3，一个由 DeepSeek 开发的新一代 AI 助手，你会为用户提供专业、准确的回答。"
                    },
                    {
                        role: "user",
                        content: question
                    }
                ],
                temperature: 0.7,
                stream: false
            })
        });

        if (!response.ok) {
            const errorText = await response.text();
            console.error('DeepSeek-V3 API 错误响应:', errorText);
            throw new Error(`HTTP error! status: ${response.status}, body: ${errorText}`);
        }

        const data = await response.json();
        console.log('收到 DeepSeek-V3 响应:', data);
        
        targetEl.querySelector('.loading-container').classList.add('hidden');
        targetEl.querySelector('.answer-text').textContent = data.choices[0].message.content;
    } catch (error) {
        console.error('Error calling DeepSeek-V3 API:', error);
        targetEl.querySelector('.loading-container').classList.add('hidden');
        targetEl.querySelector('.answer-text').textContent = "调用 API 失败：" + error.message;
    }
}

// 添加 DeepSeek-R1 普通版 API 调用函数
async function callDeepSeekReasonerApi(question, targetEl) {
    try {
        const apiKey = getApiKey('deepseek-reasoner');
        if (!apiKey) {
            throw new Error('请先填写DeepSeek-R1 API Key');
        }

        console.log('准备发送请求到 DeepSeek-R1...');
        const response = await fetch('https://api.deepseek.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`
            },
            body: JSON.stringify({
                model: "deepseek-reasoner",
                messages: [
                    {
                        role: "system",
                        content: "你是 DeepSeek-R1，一个由 DeepSeek 开发的推理模型，你会为用户提供专业、准确的回答。"
                    },
                    {
                        role: "user",
                        content: question
                    }
                ],
                temperature: 0.7,
                stream: false
            })
        });

        if (!response.ok) {
            const errorText = await response.text();
            console.error('DeepSeek-R1 API 错误响应:', errorText);
            throw new Error(`HTTP error! status: ${response.status}, body: ${errorText}`);
        }

        const data = await response.json();
        console.log('收到 DeepSeek-R1 响应:', data);
        
        targetEl.querySelector('.loading-container').classList.add('hidden');
        targetEl.querySelector('.answer-text').textContent = data.choices[0].message.content;
    } catch (error) {
        console.error('Error calling DeepSeek-R1 API:', error);
        targetEl.querySelector('.loading-container').classList.add('hidden');
        targetEl.querySelector('.answer-text').textContent = "调用 API 失败：" + error.message;
    }
}

// 将模拟调用改为实际的 ChatGPT API 调用
async function callChatGPTApi(question, targetEl) {
    try {
        console.log('准备发送请求到 ChatGPT...');
        const response = await fetch('https://kg-api.cloud/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer sk-nkgEfXWOM3ONCrmS97C66a56Ea6e49A497Ce6c36D108A546'
            },
            body: JSON.stringify({
                model: "gpt-4o-mini",
                messages: [
                    {
                        role: "system",
                        content: "你是 ChatGPT，由 OpenAI 开发的 AI 助手，你会为用户提供专业、准确的回答。"
                    },
                    {
                        role: "user",
                        content: question
                    }
                ],
                temperature: 0.7
            })
        });

        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`HTTP error! status: ${response.status}, body: ${errorText}`);
        }

        const data = await response.json();
        console.log('收到 ChatGPT 响应:', data);
        
        targetEl.querySelector('.loading-container').classList.add('hidden');
        targetEl.querySelector('.answer-text').textContent = data.choices[0].message.content;
    } catch (error) {
        console.error('Error calling ChatGPT API:', error);
        targetEl.querySelector('.loading-container').classList.add('hidden');
        targetEl.querySelector('.answer-text').textContent = "调用 API 失败：" + error.message;
    }
}

// 添加重试函数
async function retryApiCall(apiFunc, maxRetries = 3, delay = 1000) {
    for (let i = 0; i < maxRetries; i++) {
        try {
            return await apiFunc();
        } catch (error) {
            if (error.message.includes('429') && i < maxRetries - 1) {
                // 如果是限流错误且不是最后一次尝试，等待后重试
                await new Promise(resolve => setTimeout(resolve, delay * (i + 1)));
                continue;
            }
            throw error;
        }
    }
} 