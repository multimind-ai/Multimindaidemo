const express = require('express');
const cors = require('cors');
const axios = require('axios');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static('.'));

// 豆包 API 代理
app.post('/api/v3/chat/completions', async (req, res) => {
    try {
        const response = await axios({
            method: 'post',
            url: 'https://ark.cn-beijing.volces.com/api/v3/chat/completions',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer 01a6ab4b-4b7a-42f7-a370-93865d266eb0'
            },
            data: req.body
        });
        res.json(response.data);
    } catch (error) {
        console.error('Proxy Error:', error.response?.data || error.message);
        res.status(error.response?.status || 500).json({
            error: error.response?.data || error.message
        });
    }
});

const PORT = 8080;
app.listen(PORT, () => {
    console.log(`Server is running at http://localhost:${PORT}`);
}); 